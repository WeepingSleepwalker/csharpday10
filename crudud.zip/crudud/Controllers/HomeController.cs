using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using crudud.Models;

namespace crudud.Controllers 
{
    public class HomeController : Controller
    {
        private MyContext dbContext;
 
        public HomeController(MyContext context)
        {
            dbContext = context;
        }
        
        [HttpGet]
        [Route("")]
        public IActionResult Index()
        {
            ViewBag.AllDishes = dbContext.Dishes.ToList();

            return View();
        }

        [HttpGet]
        [Route("NewDish")]
        public IActionResult NewDish()
        {
            

            return View();
        }

        [HttpPost]
        [Route("CreateDish")]
        public IActionResult CreateDish(Dishes newDish)
        {
            
            dbContext.Add(newDish);
            dbContext.SaveChanges();

            return Redirect("/");
        }

        [HttpGet]
        [Route("OneDish/{dishId}")]
        public IActionResult OneDish(int dishId)
        {
             Dishes GotDish = dbContext.Dishes.FirstOrDefault(l => l.DishId == dishId);
             ViewBag.SingleDish = GotDish;

             return View();
        }
    
        [HttpGet]
        [Route("EditDish/{dishId}")]
        public IActionResult EditDish(int dishId)
        {
            Dishes EditDish = dbContext.Dishes.FirstOrDefault(l => l.DishId == dishId);
             ViewBag.SingleDish = EditDish;

            return View();
        }

        [HttpPost]
        [Route("SaveEditDish/{dishId}")]
        public IActionResult SaveEditDish(int dishId, Dishes NarDish)
        {
            Dishes ReDish = dbContext.Dishes.FirstOrDefault(l => l.DishId == dishId);
            
            
            ReDish.Name = NarDish.Name;
            ReDish.Chef = NarDish.Chef;
            ReDish.Tastiness = NarDish.Tastiness;
            ReDish.Calories = NarDish.Calories;
            ReDish.Description = NarDish.Description;
            ReDish.UpdatedAt = DateTime.Now;

            dbContext.SaveChanges();

            return Redirect("/");
        }

        [HttpGet("deleteDish/{dishId}")]
        public IActionResult deleteDish(int dishId)
        {
        
            Dishes RetrievedDish = dbContext.Dishes.SingleOrDefault(l => l.DishId == dishId);
            
            dbContext.Dishes.Remove(RetrievedDish);
            
            dbContext.SaveChanges();
     

            return Redirect("/");
        }
    
    }




}